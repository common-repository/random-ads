Installation Instructions:
http://www.datafeedr.com/random-ads-plugin.php#installation