<!-- This snippet calls the file ad_468x60.txt and displays its ads -->
<?php if (function_exists('dfrad')) { echo dfrad('ad_468x60'); } ?>



<!-- This snippet calls the file ad_468x60.txt, displays its ads
	 and wraps the ad in a div with class set to my_ad_468x60 -->
<?php 
if (function_exists('dfrad')) {
	echo '<div class="my_ad_468x60">';
	echo dfrad('ad_468x60'); 
	echo '</div>';
} 
?>
